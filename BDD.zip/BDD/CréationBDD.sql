-- Cr�ation du sch�ma de la base de donn�es 
CREATE DATABASE NFA021;

